## Authors
Brandon Franklin  
Shawn Norrie

~ April 2020

## About the app
Etchpad is a sketching application inspired by the Etch-A-Sketch. Developed over four months, Etchpad provides a simplistic but feature-rich way to sketch alone or with a friend. 

*Read the How to and get Etching!*
